/// All personal / portfolio content lives here.
/// Edit these values to update the site — no need to touch any UI file.

class ProfileData {
  ProfileData._();

  static const String name = 'Dhanraj Kharat';
  static const String tagline =
      'I build cross-platform apps and web experiences that just work.';
  static const String roles = 'Flutter Developer  —  Full-Stack Developer  —  Freelancer';

  static const String about =
      'Currently pursuing M.Sc. (Computer Applications) at Fergusson College, '
      'Pune (2026). I work across the stack — Flutter for cross-platform '
      'mobile apps, React for the web, and Firebase / SQL / Python on the '
      'backend. I am actively taking on freelance projects and love turning '
      'ideas into fast, functional, good-looking products.';

  static const String email = 'dhanrajkharat9844@gmail.com';
  static const String phone = '+91 8007317574';
  static const String phoneRaw = '918007317574';

  static const String githubUsername = 'dhanraj9844';
  static const String githubUrl = 'https://github.com/dhanraj9844';
  static const String instagramUrl =
      'https://www.instagram.com/dhanraj_kharat9844/?hl=en';
  static const String instagramHandle = '@dhanraj_kharat9844';

  static const List<String> skills = [
    'Flutter',
    'React',
    'Java',
    'Firebase',
    'SQL',
    'Python',
    'Android',
    'C',
    'HTML',
    'CSS',
    'Git & GitHub',
    'Postman',
    'Web Hosting',
  ];

  static const List<EducationItem> education = [
    EducationItem(
      title: 'M.Sc. Computer Applications',
      place: 'Fergusson College, Pune',
      period: '2026',
      description:
          'Pursuing a Master\'s in Computer Applications, focused on '
          'full-stack development, databases and applied software '
          'engineering.',
    ),
  ];

  static const List<ProjectItem> projects = [
    ProjectItem(
      title: 'NEET UG & PG Counseling Platform',
      summary:
          'A website and mobile app built for a NEET UG/PG admission '
          'counseling service. Helps students find eligible colleges based '
          'on their rank, and surfaces cutoffs, fees, bonds, required '
          'documents and the full counseling timeline in one place. ',
      tags: ['Mobile Application', 'Web', 'Client Project'],
      url: '',
    ),
    ProjectItem(
      title: 'Finance Demo',
      summary:
          'A cross-platform personal finance tracker built with Flutter '
          'and Firebase, for logging expenses and income with real-time '
          'sync across devices.',
      tags: ['Mobile Application', 'Firebase', 'Cross-platform'],
      url: 'https://github.com/dhanraj9844/Finance-Demo-',
    ),
    ProjectItem(
      title: 'Flutter App',
      summary:
          'A cross-platform mobile application built with Flutter, focused '
          'on a clean UI and smooth performance across Android and iOS.',
      tags: ['Mobile Application', 'Flutter', 'Android'],
      url: 'https://github.com/dhanraj9844/Flutter-App',
    ),
    ProjectItem(
      title: 'CloudProject',
      summary:
          'A JavaScript-based cloud/web project exploring hosting, data '
          'handling and real-world deployment workflows.',
      tags: ['JavaScript', 'Cloud', 'Web'],
      url: 'https://github.com/dhanraj9844/CloudProject',
    ),
  ];

  static const String availability = 'Available for freelance projects';
}

class EducationItem {
  final String title;
  final String place;
  final String period;
  final String description;

  const EducationItem({
    required this.title,
    required this.place,
    required this.period,
    required this.description,
  });
}

class ProjectItem {
  final String title;
  final String summary;
  final List<String> tags;
  final String url;

  const ProjectItem({
    required this.title,
    required this.summary,
    required this.tags,
    required this.url,
  });
}
