import 'package:flutter/material.dart';
import '../data/profile_data.dart';
import '../theme/app_theme.dart';
import 'reveal_on_scroll.dart';
import 'section_container.dart';

/// Icon + brand color for each skill. Uses Flutter's built-in Material
/// icon set (no external icon package / network fetch needed), tinted to
/// each technology's real brand color so it reads like a logo badge.
/// Add an entry here whenever a new skill is added to ProfileData.skills.
class _SkillVisual {
  final IconData icon;
  final Color color;
  const _SkillVisual(this.icon, this.color);
}

const Map<String, _SkillVisual> _skillVisuals = {
  'Flutter': _SkillVisual(Icons.flutter_dash, Color(0xFF02569B)),
  'React': _SkillVisual(Icons.hub, Color(0xFF61DAFB)),
  'Java': _SkillVisual(Icons.local_cafe, Color(0xFFED8B00)),
  'Firebase': _SkillVisual(Icons.local_fire_department, Color(0xFFFFCA28)),
  'SQL': _SkillVisual(Icons.storage, Color(0xFF4479A1)),
  'Python': _SkillVisual(Icons.terminal, Color(0xFF3776AB)),
  'Android': _SkillVisual(Icons.android, Color(0xFF3DDC84)),
  'C': _SkillVisual(Icons.memory, Color(0xFFA8B9CC)),
  'HTML': _SkillVisual(Icons.language, Color(0xFFE34F26)),
  'CSS': _SkillVisual(Icons.brush, Color(0xFF1572B6)),
  'Git & GitHub': _SkillVisual(Icons.account_tree, Color(0xFFF05032)),
  'Postman': _SkillVisual(Icons.send, Color(0xFFFF6C37)),
  'Web Hosting': _SkillVisual(Icons.cloud_queue, AppColors.accentGreen),
};

// Fallback for any skill added to ProfileData.skills without a matching
// entry above, so the UI never breaks — just shows a neutral generic icon.
const _SkillVisual _fallbackVisual =
    _SkillVisual(Icons.code, AppColors.accentBlue);

class SkillsSection extends StatelessWidget {
  final Key sectionKey;
  const SkillsSection({super.key, required this.sectionKey});

  @override
  Widget build(BuildContext context) {
    return SectionContainer(
      sectionKey: sectionKey,
      background: AppColors.surface.withOpacity(0.35),
      child: RevealOnScroll(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionHeading(title: 'Skills'),
            Wrap(
              spacing: 14,
              runSpacing: 14,
              children: [
                for (final skill in ProfileData.skills)
                  _SkillChip(
                    label: skill,
                    visual: _skillVisuals[skill] ?? _fallbackVisual,
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SkillChip extends StatefulWidget {
  final String label;
  final _SkillVisual visual;
  const _SkillChip({required this.label, required this.visual});

  @override
  State<_SkillChip> createState() => _SkillChipState();
}

class _SkillChipState extends State<_SkillChip> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      cursor: SystemMouseCursors.click,
      child: AnimatedScale(
        scale: _hover ? 1.06 : 1.0,
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: _hover ? AppColors.surfaceAlt : AppColors.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: _hover ? AppColors.accentGreen : AppColors.border,
            ),
            boxShadow: _hover
                ? [
                    BoxShadow(
                      color: AppColors.accentGreen.withOpacity(0.18),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ]
                : [],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 26,
                height: 26,
                decoration: BoxDecoration(
                  color: widget.visual.color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Icon(
                  widget.visual.icon,
                  size: 16,
                  color: widget.visual.color,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                widget.label,
                style: AppText.h3.copyWith(
                  fontSize: 14.5,
                  color: _hover ? AppColors.accentGreen : AppColors.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
